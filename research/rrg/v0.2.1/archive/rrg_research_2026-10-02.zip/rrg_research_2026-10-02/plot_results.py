"""Plot saved numerical trajectories; no simulation is rerun."""
from pathlib import Path
import argparse
import numpy as np
import matplotlib.pyplot as plt

def main(folder: Path) -> None:
    with np.load(folder/'results'/'traces.npz') as data:
        fig,ax=plt.subplots(figsize=(9,4.8))
        for key,label,linestyle in [
            ('seeded','Four-cell seed, wave coupling','-'),
            ('decoupled_spectrally_matched','Same seed, coupling removed and resonance matched','--'),
            ('unseeded','No seed, otherwise identical',':')]:
            count=(data[key+'_states'][:,2,:]>.3).sum(axis=1)
            ax.plot(data[key+'_times'],count,label=label,linestyle=linestyle,linewidth=2)
        ax.set(title='Exploratory RRG toy model: wave-mediated state propagation',
               xlabel='Time (dimensionless)',ylabel='Cells in the changed geometric state',
               xlim=(0,6000),ylim=(-1,34),yticks=[0,4,8,16,24,32])
        ax.legend(loc='upper left',fontsize=9);ax.grid(True,alpha=.25)
        fig.text(.5,.015,'Numerical model, not a physical experiment. State threshold g > 0.3 is used only for measurement.',ha='center',fontsize=9)
        fig.tight_layout(rect=(0,.04,1,1));fig.savefig(folder/'domain_growth.png',dpi=180,bbox_inches='tight')
        plt.close(fig)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--folder',type=Path,default=Path('.'))
    main(parser.parse_args().folder)
