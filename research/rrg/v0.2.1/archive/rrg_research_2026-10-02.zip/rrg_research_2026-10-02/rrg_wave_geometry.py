"""Exploratory geometry--mode feedback benchmark, 2026-10-02.

NOT a derivation of fundamental physics, a laboratory result, or a claim of novelty.
A driven classical ring with internal structural coordinates. Geometry potentials
are strictly convex. No copying, birth, threshold-switching, or cluster rules are
used in the equations. The threshold 0.3 is only a reporting convention.

E = sum[v_i^2/2 + a*g_i^2/2 + b*g_i^4/4 + k(g_i)*q_i^2/2]
    + J/2 sum[(q_{i+1}-q_i)^2] + D/2 sum[(g_{i+1}-g_i)^2]
k(g) = kmin + k0*exp(-2*c*g)
qdot = v; vdot = f(t) - gamma*v - dE/dq
gdot = -mu*dE/dg
Thus dE/dt = sum(f_i*v_i) - gamma*sum(v_i^2) - sum(gdot_i^2)/mu.

Default drive: f_i(t) = F*(-1)^i*cos(Omega*t), on an even periodic ring.
This imposed spatial phase pattern, the lattice, and the constitutive law are
ASSUMPTIONS, not emergent results. Energy is continuously supplied by the drive.

Run: python rrg_wave_geometry.py --out results
Dependencies: numpy, scipy, numba. Output: JSON summary and NPZ traces.
"""
from __future__ import annotations
import argparse
from dataclasses import dataclass, asdict, replace
from pathlib import Path
import json
import platform
import numpy as np
import scipy
from scipy.integrate import solve_ivp
import numba
from numba import njit

@dataclass(frozen=True)
class Parameters:
    n: int = 32
    force: float = .15
    omega: float = float(np.sqrt(.93))
    wave_coupling: float = .03
    structural_coupling: float = 0.
    geometry_sensitivity: float = .5
    mobility: float = .02
    damping: float = .1
    a: float = .5
    b: float = .1
    kmin: float = .2
    k0: float = 1.
    alternating: bool = True

    def vector(self) -> np.ndarray:
        if self.n < 2 or (self.alternating and self.n % 2):
            raise ValueError('Alternating periodic drive requires an even n >= 2.')
        vals=np.array([self.force,self.omega,self.wave_coupling,
                       self.structural_coupling,self.geometry_sensitivity,
                       self.mobility,self.damping,self.a,self.b,self.kmin,
                       self.k0,float(self.alternating)],dtype=float)
        if not np.all(np.isfinite(vals)) or np.any(vals[:11] < 0) or self.mobility <= 0:
            raise ValueError('Parameters must be finite, nonnegative; mobility > 0.')
        return vals

@njit(cache=True)
def rhs(t, y, p):
    F,om,J,D,c,mu,gamma,a,b,kmin,k0,alt=p
    n=y.shape[1]; dy=np.empty_like(y)
    for i in range(n):
        l=(i-1)%n; r=(i+1)%n
        q,v,g=y[0,i],y[1,i],y[2,i]
        ex=k0*np.exp(-2*c*g)
        f=F*np.cos(om*t)
        if alt and i%2: f=-f
        dy[0,i]=v
        dy[1,i]=f-gamma*v-(kmin+ex)*q-J*(2*q-y[0,l]-y[0,r])
        dy[2,i]=mu*(-a*g-b*g**3+c*ex*q*q-D*(2*g-y[2,l]-y[2,r]))
    return dy

@njit(cache=True)
def energy(y,p):
    _,_,J,D,c,_,_,a,b,kmin,k0,_=p
    n=y.shape[1]; total=0.
    for i in range(n):
        q,v,g=y[0,i],y[1,i],y[2,i]; r=(i+1)%n
        total+=.5*v*v+.5*a*g*g+.25*b*g**4+.5*(kmin+k0*np.exp(-2*c*g))*q*q
        total+=.5*J*(q-y[0,r])**2+.5*D*(g-y[2,r])**2
    return total

@njit(cache=True)
def powers(t,y,dy,p):
    F,om,_,_,_,mu,gamma,_,_,_,_,alt=p
    w=0.; diss=0.
    for i in range(y.shape[1]):
        f=F*np.cos(om*t)
        if alt and i%2:f=-f
        w+=f*y[1,i]
        diss+=gamma*y[1,i]**2+dy[2,i]**2/mu
    return w,diss

@njit(cache=True)
def integrate(y0,p,dt,steps,stride):
    y=y0.copy(); n=y.shape[1]
    records=np.empty((steps//stride+1,3,n)); tvals=np.empty(steps//stride+1)
    audit=np.empty((steps//stride+1,3))
    W=0.; Q=0.; e0=energy(y,p)
    records[0]=y; tvals[0]=0.; audit[0]=np.array([e0,W,Q])
    for s in range(steps):
        t=s*dt
        k1=rhs(t,y,p);w1,d1=powers(t,y,k1,p)
        y2=y+.5*dt*k1; k2=rhs(t+.5*dt,y2,p);w2,d2=powers(t+.5*dt,y2,k2,p)
        y3=y+.5*dt*k2; k3=rhs(t+.5*dt,y3,p);w3,d3=powers(t+.5*dt,y3,k3,p)
        y4=y+dt*k3; k4=rhs(t+dt,y4,p);w4,d4=powers(t+dt,y4,k4,p)
        y+=dt*(k1+2*k2+2*k3+k4)/6
        W+=dt*(w1+2*w2+2*w3+w4)/6
        Q+=dt*(d1+2*d2+2*d3+d4)/6
        if (s+1)%stride==0:
            j=(s+1)//stride; records[j]=y; tvals[j]=(s+1)*dt
            audit[j]=np.array([energy(y,p),W,Q])
    return tvals,records,audit

def initial_state(p: Parameters, seed: int=4) -> np.ndarray:
    if not 0 <= seed <= p.n: raise ValueError('Invalid seed count.')
    y=np.zeros((3,p.n)); y[2]=.075
    first=p.n//2-seed//2
    y[2,first:first+seed]=.6
    return y

def run_case(p: Parameters, seed: int=4, dt: float=.04, duration: float=6000.,
             sample_interval: float=10.) -> dict:
    if dt<=0 or duration<=0 or sample_interval<dt: raise ValueError('Invalid timing.')
    steps=int(round(duration/dt)); stride=int(round(sample_interval/dt))
    if steps%stride or not np.isclose(steps*dt,duration) or not np.isclose(stride*dt,sample_interval):
        raise ValueError('Timing must produce an integer number of samples and steps.')
    pvec=p.vector(); y0=initial_state(p,seed)
    t,y,audit=integrate(y0,pvec,dt,steps,stride)
    if not np.isfinite(y).all(): raise RuntimeError('Nonfinite solution.')
    g=y[:,2,:]; counts=np.sum(g>.3,axis=1)
    resid=audit[:,0]-audit[0,0]-audit[:,1]+audit[:,2]
    tail=g[int(len(t)*.9):]
    filled=np.flatnonzero(counts==p.n)
    active=(counts>=8)&(counts<=p.n-8)
    growth=float(np.polyfit(t[active],counts[active],1)[0]) if np.sum(active)>4 else None
    summary={
        'parameters':asdict(p),'seed_cells':seed,'dt':dt,'duration':duration,
        'count_threshold':.3,'initial_count':int(counts[0]),'final_count':int(counts[-1]),
        'first_all_converted_sample_time':float(t[filled[0]]) if len(filled) else None,
        'mean_geometry_last_10_percent':float(np.mean(tail)),
        'min_final_geometry':float(g[-1].min()),'max_final_geometry':float(g[-1].max()),
        'max_abs_energy_residual':float(np.max(np.abs(resid))),
        'relative_energy_residual_to_total_supplied_work':float(np.max(np.abs(resid))/max(abs(audit[-1,1]),1.)),
        'final_supplied_work':float(audit[-1,1]),'final_dissipated_energy':float(audit[-1,2]),
        'total_two_front_growth_cells_per_time':growth,
        'sampled_counts_every_1000_time_units':{str(int(t[i])):int(counts[i]) for i in range(0,len(t),100)},
    }
    return {'summary':summary,'times':t,'states':y,'energy_audit':audit}

def main(out: Path) -> None:
    out.mkdir(parents=True,exist_ok=True)
    base=Parameters(); summaries={}; traces={}; results={}
    cases={
        'seeded':(base,4),
        'unseeded':(base,0),
        # Removing an interaction changes the spectrum. This compensating on-site
        # stiffness preserves the driven pi-mode stiffness k(g)+4J exactly.
        'decoupled_spectrally_matched':(replace(base,wave_coupling=0.,kmin=base.kmin+4*base.wave_coupling),4),
        'no_geometry_mode_coupling':(replace(base,geometry_sensitivity=0.),4),
        'no_drive':(replace(base,force=0.),4),
        'detuned':(replace(base,omega=1.2),4),
        'uniform_phase_seeded':(replace(base,alternating=False),4),
        'uniform_phase_unseeded':(replace(base,alternating=False),0),
        'single_seed':(base,1),
        'larger_seed':(base,6),
    }
    for name,(p,seed) in cases.items():
        r=run_case(p,seed);results[name]=r;summaries[name]=r['summary']
        traces[name+'_times']=r['times'];traces[name+'_states']=r['states'];traces[name+'_audit']=r['energy_audit']
        print(name, r['summary']['final_count'], 'filled',r['summary']['first_all_converted_sample_time'],flush=True)
    fine=run_case(base,4,dt=.02)
    finer=run_case(base,4,dt=.01)
    reference=results['seeded']
    convergence={
        'dt_0.04_vs_0.02_max_abs_geometry_difference':float(np.max(np.abs(reference['states'][:,2]-fine['states'][:,2]))),
        'dt_0.02_vs_0.01_max_abs_geometry_difference':float(np.max(np.abs(fine['states'][:,2]-finer['states'][:,2]))),
        'dt_0.02_summary':fine['summary'],'dt_0.01_summary':finer['summary'],
    }
    # Independently written vectorized RHS, plus a different adaptive solver.
    def independent_rhs(t,z):
        q,v,g=z.reshape(3,base.n); p=base
        sign=(-1.)**np.arange(p.n); ex=p.k0*np.exp(-2*p.geometry_sensitivity*g)
        lap=lambda x:2*x-np.roll(x,1)-np.roll(x,-1)
        return np.concatenate((v,p.force*sign*np.cos(p.omega*t)-p.damping*v-(p.kmin+ex)*q-p.wave_coupling*lap(q),
            p.mobility*(-p.a*g-p.b*g**3+p.geometry_sensitivity*ex*q*q-p.structural_coupling*lap(g))))
    sol=solve_ivp(independent_rhs,(0.,6000.),initial_state(base).ravel(),method='DOP853',
                  t_eval=reference['times'],rtol=1e-9,atol=1e-11,max_step=.5)
    if not sol.success:raise RuntimeError(sol.message)
    check=sol.y.T.reshape(-1,3,base.n)
    convergence['independent_DOP853_max_abs_geometry_difference_from_dt_0.02']=float(np.max(np.abs(check[:,2]-fine['states'][:,2])))
    convergence['independent_DOP853_final_count']=int(np.sum(check[-1,2]>.3))
    convergence['independent_DOP853_rhs_evaluations']=int(sol.nfev)
    # Explicit local energy-identity check at arbitrary states, not just a trajectory.
    rng=np.random.default_rng(2061002);errors=[];p=base.vector()
    for _ in range(20):
        y=rng.normal(0,.2,(3,base.n));t=float(rng.uniform(0,10));dy=rhs(t,y,p)
        eps=1e-6
        numerical=(energy(y+eps*dy,p)-energy(y-eps*dy,p))/(2*eps)
        w,d=powers(t,y,dy,p);errors.append(abs(numerical-(w-d)))
    convergence['max_local_energy_identity_finite_difference_error']=float(max(errors))
    # Small, disclosed exploratory grid; omega adjusted to preserve bare detuning
    # of the pi mode when J changes. Not a preregistered or exhaustive study.
    grid=[]
    for J in [.01,.03,.06,.1]:
        for F in [.12,.15,.18]:
            p=replace(base,wave_coupling=J,force=F,omega=float(np.sqrt(.81+4*J)))
            for seed in [0,4]:
                r=run_case(p,seed)
                grid.append(r['summary'])
    summary={'status':'Exploratory toy simulation; not independently externally reviewed',
             'software':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'numba':numba.__version__},
             'cases':summaries,'verification':convergence,'exploratory_grid':grid}
    (out/'results.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    np.savez_compressed(out/'traces.npz',**traces)
    print(json.dumps(convergence,indent=2),flush=True)
    print('Wrote',out/'results.json',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=Path('results'))
    args=parser.parse_args();main(args.out)
