# Recursive Resonant Geometry: first research and numerical benchmark

**Prepared:** 2 October 2026. **Status:** exploratory research branch; not a modification of the locked foundation documents.

## 1. Question being tested

The existing RRG documents define geometry broadly as spatial and relational organization, and a mode as frequency/spectrum, phase, amplitude, spatial pattern, coupling and characteristic timescales. They do not identify a mode with one number in hertz. Their central open test is recursive closure: persistent structures should become effective units at a higher scale under approximately the same equation family, rather than a new hand-authored rule at each level.

This branch tests a narrower prerequisite:

> Can a local change of internal geometry alter waves so that the waves cause neighboring units to enter a compatible geometric state, without an explicit reproduction or compatibility-update rule?

A positive answer establishes a possible propagation mechanism inside the specified model. It does not establish obligatory expansion, true reproduction, Darwinian evolution, unlimited hierarchy, or the origin of fundamental physics.

## 2. Relevant research, and what it does not establish

**Matter–field self-organization.** Baumann et al. demonstrated a driven matter–light phase transition with a Bose–Einstein condensate in a cavity [S1]. Collective atomic organization and the cavity field are mutually coupled. Thus the basic geometry–mode feedback loop is not an unobserved or newly discovered phenomenon. This experiment does not demonstrate open-ended reproduction or scale recursion.

**Self-organized resonance.** Kachman, Owen and England numerically studied periodically driven reacting Brownian particles. In their toy chemical space, resonance matched to the forcing emerged and increased work absorption helped stabilize structures [S2]. This is a close precedent for adaptive resonance, but not a general theorem that systems maximize absorption.

**A limiting case in the opposite direction.** Kedia and colleagues studied driven multistable mechanical networks and found selection of states with low work absorption [S3]. The original 2019 preprint has a different title; the journal paper appeared in 2023. The sign of adaptation depends on the physical dynamics: strong resonant response can destabilize a configuration rather than preserve it.

**Coupled geometry and phase.** The swarmalator model couples oscillator phase to spatial motion [S4]. A 2025 colloidal realization uses hydrodynamic interactions and feedback-controlled particles [S5]. These are valuable benchmarks, but their constitutive or control rules cannot be treated as if they had themselves emerged from an unspecified primitive law.

**Nonliving pattern replication.** Ebata and Sano observed holes in a vertically vibrated potato-starch suspension deforming and replicating above a driving threshold [S6]. Pattern duplication therefore does not require biology, but duplication alone does not demonstrate heritable variation or biological evolution.

**A recent hierarchy lead.** A January 2026 preprint reports hierarchical organization of optical soliton ensembles, with local collisions and nonlocal optomechanical interactions [S7]. It is a research lead, not proof of arbitrary recursive levels. The abstract and parsed manuscript text were available for this review; PDF figure rendering failed, so no conclusions here depend on inspecting its figures.

**Effective dynamics and learning.** Engineered optical-lattice tunneling has realized a Hofstadter Hamiltonian [S8]. Physical resistor networks have demonstrated distributed learning with local learning rules [S9]. These support separate engineering avenues, not arbitrary rewriting of fundamental laws or automatic emergence of useful intelligence.

**Frequency is not unique geometry.** Distinct domains can have the same full Laplace spectrum [S10]. RRG therefore needs its full geometry–mode formulation; a scalar-frequency-to-unique-shape dictionary is not viable in general.

## 3. Model: one reciprocal energy function

There are N=32 sites on a fixed even periodic ring. Each site has a fast displacement q_i, its velocity v_i, and a slow internal structural coordinate g_i. The ring and sites already exist; g is not an emergent spacetime coordinate or a new particle count.

Define dimensionless energy

\[
E=\sum_i\left[\frac{v_i^2}{2}+U(g_i)+\frac{k(g_i)q_i^2}{2}\right]
+\frac J2\sum_i(q_{i+1}-q_i)^2
+\frac D2\sum_i(g_{i+1}-g_i)^2,
\]

\[
U(g)=\frac a2g^2+\frac b4g^4,\qquad
k(g)=k_{\min}+k_0e^{-2cg}.
\]

Both a and b are positive, so U is strictly convex and has one minimum. There is no imposed bistable structural potential. The geometry-dependent stiffness is a chosen constitutive assumption, not a derived law of nature.

The reciprocal evolution is

\[
\dot q_i=v_i,\qquad
\dot v_i=f_i(t)-\gamma v_i-\partial_{q_i}E,\qquad
\dot g_i=-\mu\partial_{g_i}E.
\]

Equivalently,

\[
\ddot q_i+\gamma\dot q_i+k(g_i)q_i
+J(2q_i-q_{i-1}-q_{i+1})=f_i(t),
\]

\[
\dot g_i=\mu\left[-ag_i-bg_i^3
+ck_0e^{-2cg_i}q_i^2
-D(2g_i-g_{i-1}-g_{i+1})\right].
\]

The wave affects geometry through the derivative of the same stiffness term by which geometry affects the wave. There is no separate instruction to strengthen a compatible edge or copy a neighbor.

### Wave-only coupling test

The principal result uses **D=0**. There is no direct intercell coupling between structural coordinates. Intercell influence must pass through the q oscillators and their wave coupling J.

The drive is

\[
f_i(t)=F(-1)^i\cos(\Omega t).
\]

All sites receive the same frequency and magnitude, but alternating phases. This spatial mode pattern is externally specified and is essential to interpreting the result. There is no time-dependent decision-maker beyond this prescribed harmonic forcing.

### Parameters and initial conditions

| Parameter | Value |
|---|---:|
| N | 32 |
| F | 0.15 |
| Omega | sqrt(0.93), about 0.964365 |
| J | 0.03 |
| D | 0 |
| c | 0.5 |
| mu | 0.02 |
| gamma | 0.1 |
| a | 0.5 |
| b | 0.1 |
| k_min | 0.2 |
| k_0 | 1 |

Initially q=v=0. Background sites have g=0.075; seeded sites have g=0.6. Four adjacent sites are seeded in the main run. The integration lasts 6000 dimensionless time units. RK4 uses step 0.04 with samples every 10 time units; additional step sizes and another solver are used for verification.

The reporting threshold g>0.3 counts changed sites. It never appears in the evolution equations.

## 4. Results

| Condition | Initially changed | Finally changed | First sampled time all 32 are changed |
|---|---:|---:|---:|
| Main seeded wave-only run | 4 | 32 | 4840 |
| Identical system without seed | 0 | 0 | Not reached |
| Intercell wave coupling removed, spectrum compensated | 4 | 4 | Not reached |
| Geometry–mode coupling removed | 4 | 0 | Not reached |
| Drive removed | 4 | 0 | Not reached |
| Drive detuned to Omega=1.2, same force amplitude | 4 | 0 | Not reached |
| One-cell seed | 1 | 32 | 5510 |
| Six-cell seed | 6 | 32 | 4500 |
| Uniform-phase drive with four-cell seed | 4 | 20 | Not reached |
| Uniform-phase drive without a seed | 0 | 32 | 120 |

Main-run counts at times 0, 1000, 2000, 3000, 4000, 5000 and 6000 are 4, 10, 14, 20, 26, 32 and 32.

The uniform-phase controls are included because they show that phase and initial state matter substantially. The result is not a demonstration that scalar frequency alone specifies geometry, or that every increase in applied drive produces causal seed growth.

### Spectrally matched disconnection

For a spatially uniform geometry under alternating drive, the driven oscillator stiffness is k(g)+4J. Removing J changes that resonance. The disconnection control therefore also changes k_min to k_min+4J=0.32. It preserves that homogeneous driven-mode stiffness while removing intercell communication. The four seed cells persist but do not spread. It does not preserve every property of the inhomogeneous coupled system.

### Exploration disclosure

Parameters and the alternating drive were chosen during exploratory trials. This was not a preregistered test. An earlier uniform-drive design with direct structural coupling could spread through that direct coupling and was not sufficient to isolate the intended mechanism.

A disclosed grid checks J in {0.01,0.03,0.06,0.1} and F in {0.12,0.15,0.18}, with seed counts zero and four. Omega is adjusted as sqrt(0.81+4J), maintaining bare alternating-mode detuning. The grid contains failure, partial-growth and spontaneous-conversion regimes as well as seed-dependent growth. Full outputs are in results.json. This is not an exhaustive phase diagram.

## 5. Analytical consistency and numerical verification

### Exact energy accounting

The equations imply

\[
\frac{dE}{dt}=\sum_i f_i v_i-\gamma\sum_i v_i^2
-\frac1\mu\sum_i\dot g_i^2.
\]

The drive supplies work; the other terms dissipate it. There is no energy-generation term. The high-g state is maintained under driving, not shown to survive indefinitely without an energy supply.

At RK4 step 0.02, cumulative supplied work is approximately 12506.4825 and dissipated energy 12474.4261. The remaining difference is stored energy relative to the initial state. Maximum energy-balance residual is 3.41e-5, about 2.72e-9 of total supplied work. This small residual checks the integration against the exact model identity; it does not validate the model as a description of a material.

At 20 arbitrary states, a finite-difference check of the local identity gives maximum absolute error about 6.75e-10.

### Solver checks

Maximum sampled geometric-coordinate discrepancy:

- RK4 steps 0.04 versus 0.02: 1.21e-5.
- RK4 steps 0.02 versus 0.01: 7.71e-7.
- Independently written vectorized right-hand side, DOP853 versus RK4 step 0.02: 7.74e-7.

DOP853 uses relative tolerance 1e-9, absolute tolerance 1e-11, maximum step 0.5, and also ends with all 32 sites changed. These are independent numerical implementations inside this session, not external replication by another researcher.

### Small initial perturbations

Six paired tests add independent Gaussian initial perturbations of standard deviation 0.005 to q, v and g. In all six unseeded cases the final changed count remains zero; all six seeded cases reach 32, at sampled times 4840 or 4850. This reduces concern about exact initial symmetry for this small perturbation scale. Continuous noise, manufacturing disorder and broad basin statistics remain untested.

### Why two persistent driven states can appear without a double well

For a homogeneous alternating mode, temporarily treat g as slow and fixed. Its harmonic displacement amplitude is approximately

\[
A(g)^2=\frac{F^2}{[k(g)+4J-\Omega^2]^2+(\gamma\Omega)^2}.
\]

Averaging the slow equation over a cycle gives

\[
\dot g\approx\mu\left[-ag-bg^3+\frac{ck_0e^{-2cg}}{2}A(g)^2\right].
\]

This approximation has three stationary g values at the chosen parameters:

| Approximate g | Stability within the scalar averaged equation |
|---:|---|
| 0.110975 | Stable |
| 0.288306 | Unstable |
| 0.559911 | Stable |

The full simulation has late mean low and high states near 0.110834 and 0.557757. The agreement is consistent with drive-induced multistability. The calculation assumes slow geometry and a homogeneous single harmonic; it is not a full Floquet stability calculation and does not derive the front velocity or prove invasion.

## 6. What has and has not been established

Within this particular model, a local geometric seed can initiate wave-mediated conversion of nearby structural states. A reciprocal energy function, driving and dissipation suffice; an explicit replication command is unnecessary.

No new cells or resonators are manufactured. The result is best described as **driven geometric-state propagation**, not biological reproduction. No daughter unit has been separated from a parent. No heritable variation, competition experiment, second emergent scale or open-ended hierarchy has been demonstrated. The material realization of the chosen k(g) has not been verified. Novelty has not been established.

The fixed lattice, uniform cell design, shape-dependent stiffness, overdamped relaxation, drive and spatial phase profile are physical assumptions. Removing a special copying law does not remove the need for underlying dynamics. A model that presupposes an external pump is not yet a closed model of the universe.

Long lifetime is not sufficient for invasion or dominance. A state can persist without recruiting anything, and stronger response can increase either reinforcement or destruction. Selection must be tested from formation, loss, conversion and resource dynamics, not inferred from resonance strength alone.

## 7. Decisive research tests

### Mechanism and robustness

Measure front motion, local energy flow and the response of the next unswitched cell. Compare intact feedback with interventions breaking either feedback direction. Measure absorbed work; equal force amplitude at different frequencies does not imply equal absorbed energy. Sweep phase, amplitude, frequency, seed size, noise and disorder. Test open boundaries and larger systems, not just a periodic ring. Specify failure criteria before the next sweep.

### Remove external pattern information

Test homogeneous or broadband energy supply, movable components and multiple modes. The target is not merely a structure that follows an imposed spatial template. A stronger candidate would select its own collective spatial organization under a generic supply of energy. Such changes are proposed future tests, not accomplished results.

### Actual replication

Require two spatially separable, independently persistent organizational units, both capable of continuing the process under equivalent resource conditions. Independence from the parent does not mean independence from fuel. Then test whether variations are transmitted and influence subsequent persistence or replication.

### Recursive closure

Let Phi_theta^t be the dynamical flow, C_n a justified coarse-graining and alpha_n a time rescaling. Test

\[
C_n\Phi_{\theta_n}^{t}(X)\approx
\Phi_{\theta_{n+1}}^{\alpha_n t}(C_nX).
\]

Identify persistent units from measured dynamics rather than assigning arbitrary groups. Fit effective parameters on one dataset, then predict unseen perturbations and interactions. Repeat at another emergent level. Predeclare allowable approximation error and effective terms; extra memory, noise or many-body terms must not be hidden. Failure may reject a particular closure/model family rather than every conceivable geometry–mode theory.

This is the central RRG test still missing from the benchmark. A large synchronized domain is not automatically a hierarchy.

### Laboratory translation

A mechanical implementation would need a measured geometry-dependent stiffness, a separately characterized structural relaxation coordinate and intercell wave coupling. The hardest practical issue is separating genuine wave-mediated structural feedback from ordinary direct deformation, heating or a control algorithm. First fit the energy terms to isolated-cell measurements, then predict and test seed-dependent propagation. Cavity self-organization can be a literature benchmark; reproducing a cold-atom laboratory is not a prerequisite for the first test.

## 8. AI branch

A separate hypothesis is that persistent dynamical modules can provide useful temporal memory, activity-dependent coupling and reusable abstractions. This is not implied by stability: a trivial frozen or synchronized state can be useless for a task.

A concrete first benchmark would use nested temporal signals, testing whether modules learned at one timescale support prediction of previously unseen combinations at a slower scale. Compare with fixed oscillator reservoirs and conventional recurrent baselines at matched state size and training budget. Ablate coupling adaptation, phase information and recursive grouping. Useful outcomes would be improved held-out prediction, transfer and retention, not visually interesting oscillation. Existing physical-learning work [S9] uses actual learning rules; those rules must be acknowledged rather than presented as spontaneous intelligence.

## 9. Scope of the ambitious claim

Changing an organized medium can change its effective response [S8], but neither the present model nor this review derives quantum mechanics, the Standard Model, Lorentz symmetry, gravity or cosmological expansion. A physical-domain conversion front and metric expansion are different observables. A future fundamental model would need independent quantitative predictions, energy accounting that includes its reservoirs, and agreement with established measurements.

Forward generation and backward constraints should meet: many models can produce superficially similar patterns. Agreement with selected outcomes is not unique identification of the source.

The useful conclusion is a bounded one: the user's proposed feedback mechanism has physical precedents and an executable, numerically checked toy realization. Recursive construction of new effective units remains the next decisive step.

## Sources

[S1] Baumann, K., Guerlin, C., Brennecke, F. & Esslinger, T. (2010). *Dicke quantum phase transition with a superfluid gas in an optical cavity.* Nature 464, 1301–1306. DOI: 10.1038/nature09009.

[S2] Kachman, T., Owen, J. A. & England, J. L. (2017). *Self-Organized Resonance during Search of a Diverse Chemical Space.* Physical Review Letters 119, 038001. DOI: 10.1103/PhysRevLett.119.038001.

[S3] Kedia, H., Pan, D., Slotine, J.-J. & England, J. L. (2023). *Drive-specific selection in multistable mechanical networks.* Journal of Chemical Physics 159, 214106. DOI: 10.1063/5.0171993. Earlier author manuscript: arXiv:1908.09332 (2019), titled *Drive-specific adaptation in disordered mechanical networks of bistable springs*.

[S4] O'Keeffe, K. P., Hong, H. & Strogatz, S. H. (2017). *Oscillators that sync and swarm.* Nature Communications 8, 1504. DOI: 10.1038/s41467-017-01190-3.

[S5] Heuthe, V.-L., Iyer, P., Gompper, G. & Bechinger, C. (2025). *Tunable colloidal swarmalators with hydrodynamic coupling.* Nature Communications 16, 10984. DOI: 10.1038/s41467-025-66830-5. Published 8 December 2025.

[S6] Ebata, H. & Sano, M. (2011). *Self-Replicating Holes in a Vertically Vibrated Dense Suspension.* Physical Review Letters 107, 088301. DOI: 10.1103/PhysRevLett.107.088301.

[S7] Wang, X. et al. (2026). *Hierarchical self-organization of highly-ordered granular ensemble of optical solitons through collective motions.* arXiv:2601.18574. Preprint submitted 26 January 2026; journal publication was not verified in this review.

[S8] Aidelsburger, M. et al. (2013). *Realization of the Hofstadter Hamiltonian with Ultracold Atoms in Optical Lattices.* Physical Review Letters 111, 185301. DOI: 10.1103/PhysRevLett.111.185301.

[S9] Stern, M., Dillavou, S., Miskin, M. Z., Durian, D. J. & Liu, A. J. (2022). *Physical learning beyond the quasistatic limit.* Physical Review Research 4, L022037. DOI: 10.1103/PhysRevResearch.4.L022037.

[S10] Gordon, C., Webb, D. & Wolpert, S. (1992). *One cannot hear the shape of a drum.* Bulletin of the American Mathematical Society 27, 134–138. DOI: 10.1090/S0273-0979-1992-00289-6. arXiv:math/9207215.

**Private project grounding:** the user's existing RRG README, Scientific Framework and Mathematical Core documents, retrieved from the Library during this conversation. Their content is not reproduced as source files in this bundle, and none was edited.
