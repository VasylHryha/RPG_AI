"""Uniform-mode averaging check, not a proof of full lattice/front stability."""
from dataclasses import asdict
from pathlib import Path
import json
import numpy as np
from scipy.optimize import brentq
from rrg_wave_geometry import Parameters

def main(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    p=Parameters()
    def rate(g: float) -> float:
        ex=p.k0*np.exp(-2*p.geometry_sensitivity*g)
        amplitude_sq=p.force**2/((p.kmin+ex+4*p.wave_coupling-p.omega**2)**2+(p.damping*p.omega)**2)
        return -p.a*g-p.b*g**3+p.geometry_sensitivity*ex*amplitude_sq/2
    grid=np.linspace(0,2,10001); roots=[]
    for lo,hi in zip(grid[:-1],grid[1:]):
        if rate(lo)*rate(hi)<0:
            g=brentq(rate,lo,hi)
            slope=(rate(g+1e-6)-rate(g-1e-6))/2e-6
            roots.append({'g':float(g),'averaged_rate_slope_without_mobility':float(slope),
                          'homogeneous_averaged_stability':'stable' if slope<0 else 'unstable'})
    result={'status':'Adiabatic single-harmonic approximation; uniform alternating mode only. Local averaged stability is not full lattice stability or a proof of invasion.',
            'parameters':asdict(p),'roots':roots}
    (out/'harmonic_balance.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=Path('results'))
    main(parser.parse_args().out)
