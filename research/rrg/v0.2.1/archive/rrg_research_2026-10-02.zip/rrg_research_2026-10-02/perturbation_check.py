"""Small initial-condition robustness check, not a stochastic-noise experiment."""
from pathlib import Path
import json
import numpy as np
from rrg_wave_geometry import Parameters, initial_state, integrate

def main(out: Path):
    out.mkdir(parents=True, exist_ok=True)
    p=Parameters(); runs=[]
    for seed_cells in (0,4):
        for random_seed in range(6):
            rng=np.random.default_rng(20261002+random_seed)
            y=initial_state(p,seed_cells)
            y += rng.normal(0.0,0.005,y.shape)
            t,states,audit=integrate(y,p.vector(),0.04,150000,250)
            counts=np.sum(states[:,2,:]>0.3,axis=1)
            filled=np.flatnonzero(counts==p.n)
            runs.append({'seed_cells':seed_cells,'random_seed':20261002+random_seed,
                         'initial_perturbation_sigma_each_coordinate':0.005,
                         'final_count':int(counts[-1]),
                         'first_all_converted_sample_time':float(t[filled[0]]) if len(filled) else None,
                         'finite':bool(np.isfinite(states).all())})
            print(runs[-1],flush=True)
    (out/'perturbation_check.json').write_text(json.dumps({'status':'Six matched initial perturbations; no continuous stochastic forcing. Exploratory, not exhaustive.','runs':runs},indent=2))

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(); parser.add_argument('--out',type=Path,default=Path('results'))
    main(parser.parse_args().out)
