# RRG research branch: wave-mediated geometric-state propagation

**Date:** 2026-10-02. **Status:** exploratory, computational, unreviewed.

A reciprocal classical wave–geometry model was constructed and tested in this conversation. Under a specified periodic drive, a localized seed causes a changed internal structural state to spread through 32 pre-existing cells. No copying, birth, threshold-switching, or cluster-promotion instruction is present in the equations.

This is **not** a laboratory result, a novelty claim, reproduction of new particles, a derivation of fundamental laws, or a demonstration of recursive hierarchy. The lattice, identical units, energy function, damping, pump, and alternating spatial drive profile are assumed. The constitutive law must eventually be matched to a real physical system.

## Contents

- `RESEARCH_NOTE.md`: interpretation, equations, assumptions, controls, limits, and primary-source bibliography.
- `rrg_wave_geometry.py`: simulation, controls, exploratory parameter grid, energy audit, step-size convergence and independently written DOP853 check.
- `perturbation_check.py`: six paired small random initial-condition perturbations. This is not continuous stochastic forcing.
- `harmonic_balance.py`: approximate uniform-mode calculation of low, intermediate and high geometric branches.
- `plot_results.py`: recreates the plot from the saved trajectories.
- `results/results.json`: full numerical summaries and software versions.
- `results/traces.npz`: sampled trajectories and energy audits for the ten main cases.
- `results/perturbation_check.json`, `results/harmonic_balance.json`: additional checks.
- `domain_growth.png`: comparison plot.
- `SHA256SUMS.txt`: checksums of the included files except the checksum file itself.

## Reproduce

Use Python in an isolated environment; install `requirements.txt`. Versions used for the main benchmark are recorded in `results/results.json`; other versions have not been tested here.

```sh
python -m pip install -r requirements.txt
python rrg_wave_geometry.py --out results
python perturbation_check.py --out results
python harmonic_balance.py --out results
python plot_results.py --folder .
```

Re-running overwrites these local result files. Keep a copy of the original bundle for comparison. The main script performs its complete disclosed exploratory grid and solver checks. It does not use internet access, a machine-learning optimizer, or an external control policy.

## Headline result

Four seeded cells become 32; zero seeded cells remain zero over 6000 dimensionless time units. Removing intercell wave coupling, while compensating the local stiffness to preserve the driven homogeneous mode frequency, leaves only the four seeded cells. Disabling the drive, reciprocal geometry–mode coupling, or sufficiently detuning the drive eliminates spreading in the tested cases.

A one-cell seed also spreads in the tested case. Six small random initial perturbations preserve the seeded/unseeded contrast. A second solver and step refinements reproduce the result. These are numerical checks, not independent external replication.

The next central RRG question remains unanswered: can stable collective structures become units of another level under the same microscopic equations, without a prescribed new grouping or drive template at that level?
