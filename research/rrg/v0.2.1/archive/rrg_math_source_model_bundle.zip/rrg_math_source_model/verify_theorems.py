"""
Minimal checks for RRG v0.2 mathematical source model.

Reduced amplitude equation:
    da/dt = mu*a + c3*a**3 - c5*a**5

Bistable interval:
    -c3**2/(4*c5) < mu < 0

Nonzero equilibria:
    a_pm**2 = (c3 +/- sqrt(c3**2 + 4*c5*mu))/(2*c5)

At a nonzero equilibrium:
    f'(a) = 2*a**2*(c3 - 2*c5*a**2)
so the lower branch is unstable and the upper branch is stable.

Background backreaction:
    Delta B = rho * I

Candidate next-mode maximum growth:
    Lambda_next = r_next + alpha*Delta B

Scale-growth sufficient condition:
    q(B) = q0*exp(-sigma*B)
    L(B) = 2*pi/q(B)
    L_{n+1}/L_n = exp(sigma*Delta B_n) > 1
"""
import math

c3 = c5 = 1.0
mu = -0.18
disc = c3*c3 + 4*c5*mu
y_minus = (c3 - math.sqrt(disc))/(2*c5)
y_plus = (c3 + math.sqrt(disc))/(2*c5)

a_minus = math.sqrt(y_minus)
a_plus = math.sqrt(y_plus)

fp_minus = 2*y_minus*(c3 - 2*c5*y_minus)
fp_plus = 2*y_plus*(c3 - 2*c5*y_plus)

rho = 1.0
alpha = 1.0
r_next = -0.50
delta_B = rho*y_plus
lambda_after = r_next + alpha*delta_B

print("a_minus =", a_minus, "unstable because f' =", fp_minus, "> 0")
print("a_plus  =", a_plus,  "stable because f' =", fp_plus, "< 0")
print("Delta B =", delta_B)
print("next mode growth before =", r_next)
print("next mode growth after  =", lambda_after)
print("next mode opens =", lambda_after > 0)
