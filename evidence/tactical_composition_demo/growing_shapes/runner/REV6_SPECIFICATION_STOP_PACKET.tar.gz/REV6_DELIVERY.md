NOT_READY — specification-stop packet, not implementation delivery

Assisted-by: Codex:GPT-6

The owner's ambiguity-stop instruction halted revision-6 implementation.
REV6_INTEGRATION_REPORT.md contains Q1 (F6 medium/checkpoint selection) and
Q2 (F8 concrete carried-history run and entropy consumers), the clause map
with honest not-implemented/not-tested dispositions, and conditional cost
estimates from stored 5.1 measurements. No fixtures or development ran.

Workspace .git is read-only in this session's supplied permission profile;
no workspace Git metadata was written and no commit is claimed. The fallback
is REV6_SPECIFICATION_STOP_PACKET.tar.gz, containing only this note, the
integration stop report, seed inventory, cost estimate, and documentary
contract receipt. REV6_PACKET_MANIFEST.json lists each member's SHA256 and
size. REV6_PACKET_VERIFICATION.json records a complete read-back verification
of archive membership, file bytes and the per-member size limit. This is
transport verification, not engine or fixture acceptance.

Inspect the archive in a separate directory before importing into an
owner-writable repository. Its paths are relative to this runner directory.
Preserve all existing files and other-session work; the archive contains no
5.1 replacements or astelia_cpp changes. A subsequent scoped documentation
commit should carry `Assisted-by: Codex:GPT-6`. Current input hashes and
rewritten HEAD are recorded in REV6_SEED_INVENTORY.json; old delivery-note
commit hashes were not reused as current identities.

The packet deliberately contains no unfinished engine skeleton or fixture
implementation that could be mistaken for completion. The 14.9 integration
gate remains open. The next work is the drafter's clarification of Q1/Q2,
followed by the authorized implementation batch and its once-at-end tiny
contract tests. F1–F8 require the owner's separate approval before execution.
